package com.example.julie.glucosioworkoutproto;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        Button button2 = findViewById(R.id.button2);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToAddReading();
            }

        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToViewHistory();
            }

        });

    }

    private void goToAddReading() {
        Intent intent = new Intent(this, AddReading.class);
        startActivity(intent);
    }
    private void goToViewHistory() {
        Intent intent = new Intent(this, ViewHistory.class);
        startActivity(intent);
    }
}
